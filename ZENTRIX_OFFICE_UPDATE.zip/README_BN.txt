ZENTRIX OFFICE UPDATE

১) ZIP Extract করুন।
২) public ফোল্ডারের index.html ফাইলটি নিন।
৩) GitHub-এ akashkhan222/zentrix-website রিপোজিটরির root-এ যান।
৪) পুরোনো index.html খুলে Edit (পেন্সিল) চাপুন অথবা Add file > Upload files দিয়ে নতুন index.html আপলোড করে পুরোনো ফাইল replace করুন।
৫) Commit changes দিন। আপডেট হতে কয়েক মিনিট লাগতে পারে।

এই সংস্করণের Office টুলগুলো ব্রাউজারেই চলে। PDF Save ব্রাউজারের Print/Save as PDF ব্যবহার করে।
বাস্তব AI, লগইন, Cloud Storage ও পেমেন্ট এখনো যুক্ত নেই। Public GitHub-এ পাসওয়ার্ড বা API key দেবেন না।
